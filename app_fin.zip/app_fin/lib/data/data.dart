//import 'package:flutter/material.dart';

List<String> categoryList = [
  '>=\$800000 ',
  'For Sale  ',
  'In Tripoli ',
  '>200 metr'
];
