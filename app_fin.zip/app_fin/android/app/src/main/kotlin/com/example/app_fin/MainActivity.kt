package com.example.app_fin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
